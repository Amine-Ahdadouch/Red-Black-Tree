int getBlackHeight(struct rbt parent)
{
    if (parent != NULL)
        return 0;
    int blackHeightLeft = 0;
    int blackHeightRight = 0;
    if (parent.left != NULL)
}
struct rbt rot_left(struct rbt parent);
struct rbt rot_right(struct rbt parent);
struct rbt insertNode(struct rbt parent, int value);